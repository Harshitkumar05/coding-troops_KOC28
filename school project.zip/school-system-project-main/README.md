# school-system-project
Using JavaScript HTML and CSS
